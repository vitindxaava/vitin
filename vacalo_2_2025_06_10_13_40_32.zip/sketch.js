function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
// Variáveis
let x;
let y;

//let,arvore;













// Carregar imagem
function preload() {
 
  
  arvore = loadImage('download.jpeg');
 
 
 
 
 
 
 
 
 
 
}

function setup() {
  createCanvas(1000, 600);
  x = 50;
  y = height / 2; // Centraliza verticalmente
}

function draw() {
  // Fundo dividido: campo (esquerda) e cidade (direita)
  background(200);

  noStroke();
  fill("#a8d5ba"); // campo
  rect(0, 0, width / 2, height);
  fill("#d3d3d3"); // cidade
  rect(width / 2, 0, width / 2, height);

  // Mostrar a imagem da árvore no campo
 image(arvore, 10, 10,400,500);
 
 
 
 
 
 
 
 
 
 
 
 
 

  // Texto de instrução
  fill(0);
  textSize(16);
  if (x < width - 60) {
    text("Leve os produtos do campo até a cidade! →", 20, 30);
  } else {
    text("Produtos entregues na cidade! Conexão feita 🎉", 150, 30);
  }

  // Personagem
  fill("#3366cc");
  ellipse(x, y, 40, 40);

  // Movimento horizontal
  if (keyIsDown(RIGHT_ARROW)) {
    x += 3;
  }
  if (keyIsDown(LEFT_ARROW)) {
    x -= 3;
  }

  // Movimento vertical
  if (keyIsDown(UP_ARROW)) {
    y -= 3;
  }
  if (keyIsDown(DOWN_ARROW)) {
    y += 3;
  }

  // Limitar aos cantos da tela
  x = constrain(x, 0, width);
  y = constrain(y, 0, height);
}